import { useState } from 'react';
export default function WasteCalculator() {
  const [inputs, setInputs] = useState({ gamma: '', distance: '', dose: '', mass: '' });
  const [result, setResult] = useState(null);
  const handleChange = (e) => setInputs({ ...inputs, [e.target.name]: e.target.value });
  const calculate = () => {
    const { gamma, distance, dose, mass } = inputs;
    const A_MBQ = dose / (gamma * (1 / (distance ** 2)));
    const A_Bq = A_MBQ * 1e6;
    const density = A_Bq / mass;
    setResult({ A_MBQ, A_Bq, density });
  };
  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded-xl shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Perhitungan Densitas Aktivitas</h2>
      {['gamma','distance','dose','mass'].map((field) => (
        <div key={field} className="mb-3">
          <label className="block text-sm capitalize mb-1">{field}</label>
          <input type="number" name={field} value={inputs[field]} onChange={handleChange}
            className="border rounded-md w-full p-2" placeholder={`Masukkan ${field}`} />
        </div>
      ))}
      <button onClick={calculate} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 w-full">Hitung</button>
      {result && (
        <div className="mt-4 p-3 border rounded-md bg-gray-50">
          <p><strong>A (MBq):</strong> {result.A_MBQ.toFixed(2)}</p>
          <p><strong>A (Bq):</strong> {result.A_Bq.toExponential(2)}</p>
          <p><strong>Densitas (Bq/g):</strong> {result.density.toExponential(2)}</p>
        </div>
      )}
    </div>
  );
}